package C_Boat;

/* c.) Create a subclass of Boat class and name it Fandango Yacht, 
 * which has the following properties and methods (MainSail color and method float());*/

public class boatMainTest {

	public static void main(String[] args) {
		fandango_Yacht floating = new fandango_Yacht();
		
		floating.Float();
		floating.stop();
		
		System.out.println("\nFANDANGO YACHT SPECIFICATIONS:");
        System.out.println("Speed: " + floating.speed + " km/h");
        System.out.println("Color: " + floating.color);
        System.out.println("Price: P" + floating.price);
        System.out.println("Name: " + floating.name);
        System.out.println("Tire Type: " + floating.mainSail_color);

	}

}
