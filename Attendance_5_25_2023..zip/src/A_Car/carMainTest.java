package A_Car;

/* a.) Create a subclass of Car class and name it Toyota-VIOS, 
 * which has the following properties and methods (tire type and method drive());*/

public class carMainTest {
	// Instantiate new object
	
	public static void main(String[] args) {
		toyota_Vios driving = new toyota_Vios();
		
		driving.drive();
		driving.stop();
		
		System.out.println("\nTOYOTA VIOS SPECIFICATIONS:");
        System.out.println("Speed: " + driving.speed + " km/h");
        System.out.println("Color: " + driving.color);
        System.out.println("Price: P" + driving.price);
        System.out.println("Name: " + driving.name);
        System.out.println("Tire Type: " + driving.tireType);
        
        
	}

}
