package C_Boat;

public class Vehicle {
	String speed = "18 kn";
	String color = "Grey";
	String price = "P 173,026,509.30";
		

		 void stop() {
			System.out.println("The boat HAS STOPPED! (Override the stop method.)");
		}
}
