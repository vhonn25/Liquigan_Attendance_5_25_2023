package B_Plane;

/* b. Create a subclass of Plane class and name it U-2 Spy Plane, 
 * which has the following properties and methods (wing span and method fly());*/

public class planeMainTest {

	public static void main(String[] args) {
		U_2_spy_plane flying = new U_2_spy_plane();
		
		flying.fly();
		flying.stop();
		
		System.out.println("\nU-2 SPY PLANE SPECIFICATIONS:");
        System.out.println("Speed: " + flying.speed + " km/h");
        System.out.println("Color: " + flying.color);
        System.out.println("Price: P" + flying.price);
        System.out.println("Name: " + flying.name);
        System.out.println("Tire Type: " + flying.wingspan);

	}

}
