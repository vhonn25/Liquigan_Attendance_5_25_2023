package B_Plane;

 class Vehicle {

	String speed = "805 km/h";
	String color = "Black";
	String price = "P 6,690,000,240.00";
		

		 void stop() {
			System.out.println("Touchdown! The plane is landing! (Override the stop method.)");
		}
}
