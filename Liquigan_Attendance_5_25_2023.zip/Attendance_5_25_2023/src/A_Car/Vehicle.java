package A_Car;

 class Vehicle {
	
	String speed = "180";
	String color = "Red";
	String price = "P425,000.00";
	

	 void stop() {
		System.out.println("Vehicle has stopped. (Override the stop method.)");
	}
}
