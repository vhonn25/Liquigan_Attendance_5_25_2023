package B_Plane;

 class Vehicle {

	String speed = "805";
	String color = "Black";
	String price = "6,690,000,240.00";
		

		 void stop() {
			System.out.println("The plane is landing! (Override the stop method.)");
		}
}
