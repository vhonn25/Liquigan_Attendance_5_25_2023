package B_Plane;

	class U_2_spy_plane extends Vehicle {

		String name = "Lockheed U-2";
		String wingspan = "31 m";
		 
		 
		@Override
		void stop() {
			 //super.stop();//
			 System.out.println("Lockheed U-2 is landing!");	        
		    }
		 
		void fly() {
			 System.out.println("U-2 Spy Plane is flying!");
		 }
}
