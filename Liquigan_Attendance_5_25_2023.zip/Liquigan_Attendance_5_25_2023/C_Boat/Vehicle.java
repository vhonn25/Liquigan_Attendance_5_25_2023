package C_Boat;

public class Vehicle {
	String speed = "18";
	String color = "Grey";
	String price = "173,026,509.30";
		

		 void stop() {
			System.out.println("The boat has stopped! (Override the stop method.)");
		}
}
