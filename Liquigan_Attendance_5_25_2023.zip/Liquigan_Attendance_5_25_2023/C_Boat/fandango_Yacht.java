package C_Boat;

public class fandango_Yacht extends Vehicle{
	
	String name = "Fandango Yacht";
	String mainSail_color = "Turquoise";
	 
	 
	@Override
	void stop() {
		 //super.stop();//
		 System.out.println("The boat is anchoring!");        
	    }
	 
	void Float() {
		 System.out.println("Fandango Yacht starts floating!");
	 }
	
}
