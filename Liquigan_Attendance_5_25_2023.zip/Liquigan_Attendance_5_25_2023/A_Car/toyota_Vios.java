package A_Car;

 class toyota_Vios extends Vehicle {
	
	 String name = "Toyota VIOS";
	 String tireType = "Summer";
	 
	 
	 @Override
	 public void stop() {
		 //super.stop();//
		 System.out.println("Toyota VIOS has stopped.");
	    }
	 
	 public void drive() {
		 System.out.println("Toyota VIOS is driving.");
		 
	 }
}
